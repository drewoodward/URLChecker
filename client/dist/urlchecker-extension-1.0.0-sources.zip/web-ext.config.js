import { defineRunnerConfig } from 'wxt';

export default defineRunnerConfig({
  binaries: {
    firefox: '/Applications/Firefox.app/Contents/MacOS/firefox',
  },
});
